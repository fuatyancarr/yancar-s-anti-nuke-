const { createModel } = require('../Handler/Database/Model');

module.exports = createModel('snapshots', 'guildId', {
    guildId: null,
    roles: [],
    channels: [],
    updatedAt: null,
});
