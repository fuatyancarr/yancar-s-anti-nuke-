const { createModel } = require('../Handler/Database/Model');

module.exports = createModel('guildSettings', 'guildId', {
    guildId: null,
    whitelist: {
        roles: [],
        channels: [],
        webhooks: [],
        kicks: [],
        bans: [],
        antibot: [],
        guildUpdate: [],
        everyone: [],
    },
    actions: [],
    logChannel: null,
    enabled: {
        roles: false,
        channels: false,
        webhooks: false,
        kicks: false,
        bans: false,
        antibot: false,
        guildUpdate: false,
        everyone: false,
    },
    ownerLevel: [],
});
