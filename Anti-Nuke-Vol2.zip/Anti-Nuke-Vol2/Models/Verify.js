const { createModel } = require('../Handler/Database/Model');

module.exports = createModel('verify', 'guildId', {
    guildId: null,
    roleId: null,
    channelId: null,
    logChannelId: null,
    messageId: null,
});
