const { createModel } = require('../Handler/Database/Model');

module.exports = createModel('otorol', 'guildId', {
    guildId: null,
    rolId: null,
    aktif: true,
});
