const { createModel } = require('../Handler/Database/Model');

module.exports = createModel('premiums', 'Id', {
    Id: null,
    isPremium: false,
    premium: {
        redeemedBy: null,
        redeemedAt: null,
        expiresAt: null,
        plan: null,
    },
});
