const { createModel } = require('../Handler/Database/Model');

module.exports = createModel('hosgeldin', 'guildId', {
    guildId: null,
    kanalId: null,
    mesaj: "Sunucuya hoş geldin, {kullanici}! 🎉",
    embedRenk: "#5865F2",
    aktif: true,
});
