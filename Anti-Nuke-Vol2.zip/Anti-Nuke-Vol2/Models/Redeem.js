const { createModel } = require('../Handler/Database/Model');

module.exports = createModel('redeems', 'code', {
    code: null,
    expiresAt: null,
    plan: null,
});
