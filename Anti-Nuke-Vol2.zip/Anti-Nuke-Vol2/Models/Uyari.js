const { createModel } = require('../Handler/Database/Model');

module.exports = createModel(
    'uyarilar',
    (data) => (data && data.guildId && data.userId) ? `${data.guildId}_${data.userId}` : null,
    {
        guildId: null,
        userId: null,
        uyarilar: [],
    }
);
