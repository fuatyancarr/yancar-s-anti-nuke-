const { EmbedBuilder, AuditLogEvent, PermissionFlagsBits } = require("discord.js");
const GuildSettings = require("../Models/Antinuke");
const Snapshot = require("../Models/Snapshot");

module.exports = (client) => {
  const restoringChannels = new Set();
  const processingDeletes = new Set();
  const restoringRoles = new Set();
  const processingRoleDeletes = new Set();

  // === Whitelist helper: kullanici ID'si veya rollerinden biri whitelist'te mi? ===
  function isTrusted(guild, userId, whitelist) {
    if (!whitelist || !whitelist.length) return false;
    if (whitelist.includes(userId)) return true;
    const member = guild.members.cache.get(userId);
    if (!member) return false;
    return member.roles.cache.some(r => whitelist.includes(r.id));
  }

  //=================================== Anti Channel Events ===================================//
  client.on("channelCreate", async (channel) => {
    if (restoringChannels.has(`${channel.guild.id}:${channel.name}`)) return;
    if(!channel.guild.members.me.permissions.has(PermissionFlagsBits.ViewAuditLog)) return;
    const auditlogs = await channel.guild.fetchAuditLogs({
      type: AuditLogEvent.ChannelCreate,
      limit: 1,
    });
    const logs = auditlogs.entries.first();
    if(!logs) return;
    const { executor } = logs;

    await GuildSettings.findOne(
      { guildId: channel.guild.id },
      async (err, data) => {
        if(!data) return;
        const antinuke = data.enabled.channels;
        const trusted = isTrusted(channel.guild, executor.id, data.whitelist.channels);
        const owner = data.ownerLevel.includes(executor.id);

        if (executor.id === channel.guild.ownerId) return;
        if (executor.id === client.user.id) return;
        if (antinuke === false) return;
        if (trusted === true) return;
        if (owner === true) return;

        channel.delete();
        const member = await channel.guild.members.fetch(executor.id).catch(() => null);
        if (member) member.ban({ reason: "© Nityam Anti Channel Create" }).catch(() => {});

        const logChannel = channel.guild.channels.cache.get(data.logChannel);
        if (logChannel) {
          logChannel.send({
            embeds: [
              new EmbedBuilder()
                .setColor(client.color)
                .setAuthor({
                  name: client.user.username,
                  iconURL: client.user.displayAvatarURL(),
                })
                .addFields(
                  {
                    name: "Category",
                    value: `> Anti Channel Create`,
                  },
                  {
                    name: "Log Type",
                    value: "> User Banned",
                  },
                  {
                    name: "User",
                    value: `> ${executor} ${executor.id}`,
                  },
                  {
                    name: "Reason",
                    value: `> Creating Channels`,
                  }
                )
                .setFooter({ text: `© Nityam Antinuke Logs` })
                .setTimestamp(),
            ],
          });
        }
      }
    );
  });

  client.on("channelDelete", async (channel) => {
    if (processingDeletes.has(channel.id)) return;
    processingDeletes.add(channel.id);
    setTimeout(() => processingDeletes.delete(channel.id), 30000);
    if(!channel.guild.members.me.permissions.has(PermissionFlagsBits.ViewAuditLog)) return;
    const auditlogs = await channel.guild.fetchAuditLogs({
      type: AuditLogEvent.ChannelDelete,
      limit: 1,
    });
    const logs = auditlogs.entries.first();
    if(!logs) return;
    const { executor } = logs;

    await GuildSettings.findOne(
      { guildId: channel.guild.id },
      async (err, data) => {
        if(!data) return;
        const antinuke = data.enabled.channels;
        const trusted = isTrusted(channel.guild, executor.id, data.whitelist.channels);
        const owner = data.ownerLevel.includes(executor.id);

        if (executor.id === channel.guild.ownerId) return;
        if (executor.id === client.user.id) return;
        if (antinuke === false) return;
        if (trusted === true) return;
        if (owner === true) return;

        (async () => {
          try {
            const snap = await Snapshot.findOne({ guildId: channel.guild.id });
            const snapCh = snap && snap.channels.find(ch => ch.id === channel.id);
            if (snapCh) {
              const opts = {
                name: snapCh.name,
                type: snapCh.channelType,
                position: snapCh.position,
                permissionOverwrites: snapCh.permissionOverwrites.map(o => ({
                  id: o.id, type: o.channelType,
                  allow: BigInt(o.allow), deny: BigInt(o.deny),
                })),
              };
              if (snapCh.topic) opts.topic = snapCh.topic;
              if (snapCh.nsfw !== undefined) opts.nsfw = snapCh.nsfw;
              if (snapCh.rateLimitPerUser) opts.rateLimitPerUser = snapCh.rateLimitPerUser;
              if (snapCh.bitrate) opts.bitrate = snapCh.bitrate;
              if (snapCh.userLimit) opts.userLimit = snapCh.userLimit;
              if (snapCh.parentId && snap) {
                const parentSnap = snap.channels.find(ch => ch.id === snapCh.parentId);
                if (parentSnap) {
                  const existingCat = channel.guild.channels.cache.find(
                    ch => ch.name === parentSnap.name && ch.type === 4
                  );
                  if (existingCat) opts.parent = existingCat.id;
                }
              }
              const restoringKey = `${channel.guild.id}:${snapCh.name}`;
              restoringChannels.add(restoringKey);
              const created = await channel.guild.channels.create(opts).catch(() => null);
              if (created && snapCh.parentId && !opts.parent && snap) {
                setTimeout(async () => {
                  const parentSnap = snap.channels.find(ch => ch.id === snapCh.parentId);
                  if (parentSnap) {
                    const cat = channel.guild.channels.cache.find(
                      ch => ch.name === parentSnap.name && ch.type === 4
                    );
                    if (cat) await created.setParent(cat.id, { lockPermissions: false }).catch(() => {});
                  }
                }, 4000);
              }
              setTimeout(() => restoringChannels.delete(restoringKey), 5000);
            } else {
              const restoringKeyClone = `${channel.guild.id}:${channel.name}`;
              restoringChannels.add(restoringKeyClone);
              await channel.clone().catch(() => {});
              setTimeout(() => restoringChannels.delete(restoringKeyClone), 5000);
            }
          } catch {
            const restoringKeyCatch = `${channel.guild.id}:${channel.name}`;
            restoringChannels.add(restoringKeyCatch);
            await channel.clone().catch(() => {});
            setTimeout(() => restoringChannels.delete(restoringKeyCatch), 5000);
          }
        })();

        const member = await channel.guild.members.fetch(executor.id).catch(() => null);
        if (member) member.ban({ reason: "© Nityam Anti Channel Delete" }).catch(() => {});

        const logChannel = channel.guild.channels.cache.get(data.logChannel);
        if (logChannel) {
          logChannel.send({
            embeds: [
              new EmbedBuilder()
                .setColor(client.color)
                .setAuthor({
                  name: client.user.username,
                  iconURL: client.user.displayAvatarURL(),
                })
                .addFields(
                  {
                    name: "Category",
                    value: `> Anti Channel Delete`,
                  },
                  {
                    name: "Log Type",
                    value: "> User Banned",
                  },
                  {
                    name: "User",
                    value: `> ${executor} ${executor.id}`,
                  },
                  {
                    name: "Reason",
                    value: `> Deleting Channels`,
                  }
                )
                .setFooter({ text: `© Nityam Antinuke Logs` })
                .setTimestamp(),
            ],
          });
        }
      }
    );
  });

  client.on("channelUpdate", async (o, n) => {
    if(!n.guild.members.me.permissions.has(PermissionFlagsBits.ViewAuditLog)) return;
    const auditlogs = await n.guild.fetchAuditLogs({
      type: AuditLogEvent.ChannelUpdate,
      limit: 1,
    });
    const logs = auditlogs.entries.first();
    if(!logs) return;
    const { executor } = logs;

    await GuildSettings.findOne({ guildId: o.guild.id }, async (err, data) => {
      if(!data) return;
      const antinuke = data.enabled.channels;
      const trusted = isTrusted(channel.guild, executor.id, data.whitelist.channels);
      const owner = data.ownerLevel.includes(executor.id);

      if (executor.id === o.guild.ownerId) return;
      if (executor.id === client.user.id) return;
      if (antinuke === false) return;
      if (trusted === true) return;
      if (owner === true) return;

      const oldName = o.name;
      const newName = n.name;

      const member = await n.guild.members.fetch(executor.id).catch(() => null);
      if (member) member.ban({ reason: "© Nityam Anti Channel Update" }).catch(() => {});

      const logChannel = channel.guild.channels.cache.get(data.logChannel);
      if (logChannel) {
        logChannel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(client.color)
              .setAuthor({
                name: client.user.username,
                iconURL: client.user.displayAvatarURL(),
              })
              .addFields(
                {
                  name: "Category",
                  value: `> Anti Channel Update`,
                },
                {
                  name: "Log Type",
                  value: "> User Banned",
                },
                {
                  name: "User",
                  value: `> ${executor} ${executor.id}`,
                },
                {
                  name: "Reason",
                  value: `> Updating Channels`,
                }
              )
              .setFooter({ text: `© Nityam Antinuke Logs` })
              .setTimestamp(),
          ],
        });
      }

      if (oldName !== newName) {
        await n.edit({
          name: oldName,
        });
      }
      if (n.isText()) {
        const oldTopic = o.topic;
        const newTopic = n.topic;
        if (oldTopic !== newTopic) {
          await n.setTopic(oldTopic);
        }
      }
    });
  });

  //=================================== Anti Role Events ===================================//

  client.on("roleCreate", async (role) => {
    if (restoringRoles.has(`${role.guild.id}:${role.name}`)) return;
    if(!role.guild.members.me.permissions.has(PermissionFlagsBits.ViewAuditLog)) return;
    const auditlogs = await role.guild.fetchAuditLogs({
      type: AuditLogEvent.RoleCreate,
      limit: 1,
    });
    const logs = auditlogs.entries.first();
    if(!logs) return;
    const { executor } = logs;

    await GuildSettings.findOne(
      { guildId: role.guild.id },
      async (err, data) => {
        if(!data) return;
        const antinuke = data.enabled.roles;
        const trusted = isTrusted(role.guild, executor.id, data.whitelist.roles);
        const owner = data.ownerLevel.includes(executor.id);

       
        if (executor.id === role.guild.ownerId) return;
        if (executor.id === client.user.id) return;
        if (antinuke === false) return;
        if (trusted === true) return;
        if (owner === true) return;

        role.delete();
        const member = await role.guild.members.fetch(executor.id).catch(() => null);
        if (member) member.ban({ reason: "© Nityam Anti Role Create" }).catch(() => {});

        const logChannel = role.guild.channels.cache.get(data.logChannel);
        if (logChannel) {
          logChannel.send({
            embeds: [
              new EmbedBuilder()
                .setColor(client.color)
                .setAuthor({
                  name: client.user.username,
                  iconURL: client.user.displayAvatarURL(),
                })
                .addFields(
                  {
                    name: "Category",
                    value: `> Anti Role Create`,
                  },
                  {
                    name: "Log Type",
                    value: "> User Banned",
                  },
                  {
                    name: "User",
                    value: `> ${executor} ${executor.id}`,
                  },
                  {
                    name: "Reason",
                    value: `> Creating Roles`,
                  }
                )
                .setFooter({ text: `© Nityam Antinuke Logs` })
                .setTimestamp(),
            ],
          });
        }
      }
    );
  });

  client.on("roleUpdate", async (o, n) => {
    if(!n.guild.members.me.permissions.has(PermissionFlagsBits.ViewAuditLog)) return;
    const auditlogs = await n.guild.fetchAuditLogs({
      type: AuditLogEvent.RoleUpdate,
      limit: 1,
    });
    const logs = auditlogs.entries.first();
    if(!logs) return;
    const { executor } = logs;

    await GuildSettings.findOne({ guildId: o.guild.id }, async (err, data) => {
     if(!data) return;
      const antinuke = data.enabled.roles;
      const trusted = isTrusted(n.guild, executor.id, data.whitelist.roles);
      const owner = data.ownerLevel.includes(executor.id);

      if (executor.id === n.guild.ownerId) return;
      if (executor.id === client.user.id) return;
      if (antinuke === false) return;
      if (trusted === true) return;
      if (owner === true) return;

      n.setPermissions(o.permissions);
      const member = await n.guild.members.fetch(executor.id).catch(() => null);
      if (member) member.ban({ reason: "© Nityam Anti Role Update" }).catch(() => {});

      const logChannel = n.guild.channels.cache.get(data.logChannel);
      if (logChannel) {
        logChannel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(client.color)
              .setAuthor({
                name: client.user.username,
                iconURL: client.user.displayAvatarURL(),
              })
              .addFields(
                {
                  name: "Category",
                  value: `> Anti Role Update`,
                },
                {
                  name: "Log Type",
                  value: "> User Banned",
                },
                {
                  name: "User",
                  value: `> ${executor} ${executor.id}`,
                },
                {
                  name: "Reason",
                  value: `> Updating Roles`,
                }
              )
              .setFooter({ text: `© Nityam Antinuke Logs` })
              .setTimestamp(),
          ],
        });
      }
    });
  });

  client.on("roleDelete", async (role) => {
    if (processingRoleDeletes.has(role.id)) return;
    processingRoleDeletes.add(role.id);
    setTimeout(() => processingRoleDeletes.delete(role.id), 30000);
    if(!role.guild.members.me.permissions.has(PermissionFlagsBits.ViewAuditLog)) return;
    const auditlogs = await role.guild.fetchAuditLogs({
      type: AuditLogEvent.RoleDelete,
      limit: 1,
    });
    const logs = auditlogs.entries.first();
    if(!logs) return;
    const { executor } = logs;

    await GuildSettings.findOne(
      { guildId: role.guild.id },
      async (err, data) => {
        if(!data) return;
        const antinuke = data.enabled.roles;
        const trusted = isTrusted(role.guild, executor.id, data.whitelist.roles);
        const owner = data.ownerLevel.includes(executor.id);

       
        if (executor.id === role.guild.ownerId) return;
        if (executor.id === client.user.id) return;
        if (antinuke === false) return;
        if (trusted === true) return;
        if (owner === true) return;
        if (role.managed) return;

        (async () => {
          try {
            const snap = await Snapshot.findOne({ guildId: role.guild.id });
            const snapR = snap && snap.roles.find(r => r.id === role.id);
            if (snapR) {
              const restoringRoleKey = `${role.guild.id}:${snapR.name}`;
              restoringRoles.add(restoringRoleKey);
              await role.guild.roles.create({
                name: snapR.name,
                color: snapR.color,
                permissions: BigInt(snapR.permissions),
                hoist: snapR.hoist,
                mentionable: snapR.mentionable,
                position: snapR.position,
              }).catch(() => {});
              setTimeout(() => restoringRoles.delete(restoringRoleKey), 5000);
            } else {
              const restoringRoleKey = `${role.guild.id}:${role.name}`;
              restoringRoles.add(restoringRoleKey);
              await role.guild.roles.create({ name: role.name, color: role.color }).catch(() => {});
              setTimeout(() => restoringRoles.delete(restoringRoleKey), 5000);
            }
          } catch {
            const restoringRoleKey = `${role.guild.id}:${role.name}`;
            restoringRoles.add(restoringRoleKey);
            role.guild.roles.create({ name: role.name, color: role.color }).catch(() => {});
            setTimeout(() => restoringRoles.delete(restoringRoleKey), 5000);
          }
        })();
        const member = await role.guild.members.fetch(executor.id).catch(() => null);
        if (member) member.ban({ reason: "© Nityam Anti Role Delete" }).catch(() => {});

        const logChannel = role.guild.channels.cache.get(data.logChannel);
        if (logChannel) {
          logChannel.send({
            embeds: [
              new EmbedBuilder()
                .setColor(client.color)
                .setAuthor({
                  name: client.user.username,
                  iconURL: client.user.displayAvatarURL(),
                })
                .addFields(
                  {
                    name: "Category",
                    value: `> Anti Role Delete`,
                  },
                  {
                    name: "Log Type",
                    value: "> User Banned",
                  },
                  {
                    name: "User",
                    value: `> ${executor} ${executor.id}`,
                  },
                  {
                    name: "Reason",
                    value: `> Deleting Roles`,
                  }
                )
                .setFooter({ text: `© Nityam Antinuke Logs` })
                .setTimestamp(),
            ],
          });
        }
      }
    );
  });

  //=================================== Anti Member Events ===================================//
  client.on("guildMemberUpdate", async (o, n) => {
    if(!n.guild.members.me.permissions.has(PermissionFlagsBits.ViewAuditLog)) return;
    const auditLogs = await n.guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.MemberRoleUpdate,
    });
    const logs = auditLogs.entries.first();
    if(!logs) return;
    const { executor, target } = logs;

    await GuildSettings.findOne({ guildId: o.guild.id }, async (err, data) => {

     if(!data) return;
      const antinuke = data.enabled.roles;
      const trusted = isTrusted(n.guild, executor.id, data.whitelist.roles);
      const owner = data.ownerLevel.includes(executor.id);

      if (antinuke === false) return;
      if (trusted === true) return;
      if (owner === true) return;
      if (executor.id === client.user.id) return;
      if (executor.id === n.guild.ownerId) return;

      const oldRoles = o.roles;
      const newRoles = n.roles;

      if (oldRoles !== newRoles) {
        n.roles.set(o.roles.cache);
      }

      const member = await n.guild.members.fetch(executor.id).catch(() => null);
      if (member) member.ban({ reason: "© Nityam Anti Member Role Update" }).catch(() => {});

      const logChannel = n.guild.channels.cache.get(data.logChannel);
      if (logChannel) {
        logChannel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(client.color)
              .setAuthor({
                name: client.user.username,
                iconURL: client.user.displayAvatarURL(),
              })
              .addFields(
                {
                  name: "Category",
                  value: `> Anti Member Role Update`,
                },
                {
                  name: "Log Type",
                  value: "> User Banned",
                },
                {
                  name: "User",
                  value: `> ${executor} ${executor.id}`,
                },
                {
                  name: "Reason",
                  value: `> Updating Member Roles`,
                }
              )
              .setFooter({ text: `© Nityam Antinuke Logs` })
              .setTimestamp(),
          ],
        });
      }
    });
  });

  //=================================== Anti Ban Events ===================================//
  client.on("guildBanAdd", async (member) => {
    if(!member.guild.members.me.permissions.has(PermissionFlagsBits.ViewAuditLog)) return;
    const auditLogs = await member.guild.fetchAuditLogs({
      type: AuditLogEvent.MemberBanAdd,
      limit: 1,
    });
    const logs = auditLogs.entries.first();
    if(!logs) return;
    const { executor, target } = logs;

    await GuildSettings.findOne(
      { guildId: member.guild.id },
      async (err, data) => {
        if(!data) return;
        const antinuke = data.enabled.bans;
        const trusted = isTrusted(member.guild, executor.id, data.whitelist.bans);
        const owner = data.ownerLevel.includes(executor.id);

        if (antinuke === false) return;
        if (trusted === true) return;
        if (member.id !== target.id) return;
        if (owner === true) return;
        if (executor.id === client.user.id) return;
        if (executor.id === member.guild.ownerId) return;

        const member2 = await member.guild.members.fetch(executor.id).catch(() => null);
        if (member2) member2.ban({ reason: "© Nityam Anti Member Ban " }).catch(() => {});

        const logChannel = member.guild.channels.cache.get(data.logChannel);
        if (logChannel) {
          logChannel.send({
            embeds: [
              new EmbedBuilder()
                .setColor(client.color)
                .setAuthor({
                  name: client.user.username,
                  iconURL: client.user.displayAvatarURL(),
                })
                .addFields(
                  {
                    name: "Category",
                    value: `> Anti Member Ban`,
                  },
                  {
                    name: "Log Type",
                    value: "> User Banned",
                  },
                  {
                    name: "User",
                    value: `> ${executor} ${executor.id}`,
                  },
                  {
                    name: "Reason",
                    value: "> Baning Members",
                  },
                  {
                    name: "Target",
                    value: `> ${target} ${target.id}`,
                  }
                )
                .setFooter({ text: `© Nityam Antinuke Logs` })
                .setTimestamp(),
            ],
          });
        }
      }
    );
  });

  //=================================== Anti Kick Events ===================================//
  client.on("guildMemberRemove", async (member) => {
    if(!member.guild.members.me.permissions.has(PermissionFlagsBits.ViewAuditLog)) return;
    const auditLogs = await member.guild.fetchAuditLogs({
      type: AuditLogEvent.MemberKick,
      limit: 1,
    });
    const logs = auditLogs.entries.first();
    if(!logs) return;
    const { executor, target } = logs;

    await GuildSettings.findOne(
      { guildId: member.guild.id },
      async (err, data) => {
        if(!data) return;
        const antinuke = data.enabled.kicks;
        const trusted = isTrusted(member.guild, executor.id, data.whitelist.kicks);
        const owner = data.ownerLevel.includes(executor.id);

        if (executor.id === client.user.id) return;
        if (executor.id === member.guild.ownerId) return;
        if (antinuke === false) return;
        if (member.id !== target.id) return;
        if (trusted === true) return;
        if (owner === true) return;

        const member2 = await member.guild.members.fetch(executor.id).catch(() => null);
        if (member2) member2.ban({ reason: "© Nityam Anti Member Kick " }).catch(() => {});
        // Kick yiyen kişiye davet linki gönder
        try {
          const inviteChannel = member.guild.channels.cache.find(c => c.isTextBased() && c.permissionsFor(member.guild.members.me).has(PermissionFlagsBits.CreateInstantInvite));
          if (inviteChannel) {
            const invite = await inviteChannel.createInvite({ maxAge: 86400, maxUses: 1, reason: 'Antinuke: Kick geri alımı' }).catch(() => null);
            if (invite) {
              await target.send({
                embeds: [
                  new EmbedBuilder()
                    .setColor(0x57F287)
                    .setTitle('Sunucuya Geri Dön')
                    .setDescription(`**${member.guild.name}** sunucusunda yetkisiz şekilde atıldınız. Aşağıdaki link ile geri dönebilirsiniz (24 saat geçerli).`)
                    .addFields({ name: 'Davet Linki', value: `https://discord.gg/${invite.code}` })
                    .setFooter({ text: '© Nityam Antinuke' })
                    .setTimestamp()
                ]
              }).catch(() => {});
            }
          }
        } catch(e) {}

        const logChannel = member.guild.channels.cache.get(data.logChannel);
        if (logChannel) {
          logChannel.send({
            embeds: [
              new EmbedBuilder()
                .setColor(client.color)
                .setAuthor({
                  name: client.user.username,
                  iconURL: client.user.displayAvatarURL(),
                })
                .addFields(
                  {
                    name: "Category",
                    value: `> Anti Member Kick`,
                  },
                  {
                    name: "Log Type",
                    value: "> User Banned",
                  },
                  {
                    name: "User",
                    value: `> ${executor} ${executor.id}`,
                  },
                  {
                    name: "Reason",
                    value: "> Kicking Members",
                  },
                  {
                    name: "Target",
                    value: `> ${target} ${target.id}`,
                  }
                )
                .setFooter({ text: `© Nityam Antinuke Logs` })
                .setTimestamp(),
            ],
          });
        }
      }
    );
  });

  //=================================== Anti Bot Events ===================================//
  client.on("guildMemberAdd", async (member) => {
    if(!member.guild.members.me.permissions.has(PermissionFlagsBits.ViewAuditLog)) return;
    const auditLogs = await member.guild.fetchAuditLogs({
      type: AuditLogEvent.BotAdd,
      limit: 1,
    });
    const logs = auditLogs.entries.first();
    if(!logs) return;
    const { executor, target } = logs;

    await GuildSettings.findOne(
      { guildId: member.guild.id },
      async (err, data) => {
        if(!data) return;
        const antinuke = data.enabled.antibot;
        const trusted = isTrusted(member.guild, executor.id, data.whitelist.antibot);
        const owner = data.ownerLevel.includes(executor.id);

        if (executor.id === client.user.id) return;
        if (executor.id === member.guild.ownerId) return;
        if (antinuke === false) return;
        if (trusted === true) return;
        if (!target.bot) return;
        if (owner === true) return;
        if (target.id !== member.id) return;

        const member3 = await member.guild.members.fetch(executor.id).catch(() => null);
        if (member3) member3.ban({ reason: "© Nityam Anti Bot Add " }).catch(() => {});
        const member2 = member.guild.members.fetch(target.id);
        if (member2) member2.ban({ reason: "© Nityam Anti Bot Add " }).catch(() => {});

        const logChannel = member.guild.channels.cache.get(data.logChannel);
        if (logChannel) {
          logChannel.send({
            embeds: [
              new EmbedBuilder()
                .setColor(client.color)
                .setAuthor({
                  name: client.user.username,
                  iconURL: client.user.displayAvatarURL(),
                })
                .addFields(
                  {
                    name: "Category",
                    value: `> Anti Bot Add`,
                  },
                  {
                    name: "Log Type",
                    value: "> User Banned",
                  },
                  {
                    name: "User",
                    value: `> ${executor} ${executor.id}`,
                  },
                  {
                    name: "Reason",
                    value: "> Illegal Bot Add",
                  },
                  {
                    name: "Bot",
                    value: `> ${target} ${target.id}`,
                  }
                )
                .setFooter({ text: `© Nityam Antinuke Logs` })
                .setTimestamp(),
            ],
          });
        }
      }
    );
  });

  //=================================== Anti Webhook Events ===================================//

  client.on("webhookUpdate", async (webhook) => {
    if(!webhook.guild.members.me.permissions.has(PermissionFlagsBits.ViewAuditLog)) return;
    const auditLog = await webhook.guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.WebhookUpdate,
    });
    const logs = auditLog.entries.first();
    if(!logs) return;
    const { executor } = logs;

    await GuildSettings.findOne(
      { guildId: webhook.guild.id },
      async (err, data) => {
        if(!data) return;
        const antinuke = data.enabled.webhooks;
        const trusted = isTrusted(webhook.guild, executor.id, data.whitelist.webhooks);
        const owner = data.ownerLevel.includes(executor.id);

        if (antinuke === false) return;
        if (trusted === true) return;
        if (owner === true) return;
        if (executor.id === client.user.id) return;
        if (executor.id === webhook.guild.ownerId) return;

        const member = await webhook.guild.members.fetch(executor.id).catch(() => null);
        if (member) member.ban({ reason: "© Nityam Anti Webhook Update" }).catch(() => {});

        const logChannel = webhook.guild.channels.cache.get(data.logChannel);
        if (logChannel) {
          logChannel.send({
            embeds: [
              new EmbedBuilder()
                .setColor(client.color)
                .setAuthor({
                  name: client.user.username,
                  iconURL: client.user.displayAvatarURL(),
                })
                .addFields(
                  {
                    name: "Category",
                    value: `> Anti Webhook Update`,
                  },
                  {
                    name: "Log Type",
                    value: "> User Banned",
                  },
                  {
                    name: "User",
                    value: `> ${executor} ${executor.id}`,
                  },
                  {
                    name: "Reason",
                    value: "> Updating Webhook",
                  }
                )
                .setFooter({ text: `© Nityam Antinuke Logs` })
                .setTimestamp(),
            ],
          });
        }
      }
    );
  });

  client.on("webhookUpdate", async (webhook) => {
    if(!webhook.guild.members.me.permissions.has(PermissionFlagsBits.ViewAuditLog)) return;
    const auditLog = await webhook.guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.WebhookCreate,
    });
    const logs = auditLog.entries.first();
    if(!logs) return;
    const { executor } = logs;

    await GuildSettings.findOne(
      { guildId: webhook.guild.id },
      async (err, data) => {
        if(!data) return;
        const antinuke = data.enabled.webhooks;
        const trusted = isTrusted(webhook.guild, executor.id, data.whitelist.webhooks);
        const owner = data.ownerLevel.includes(executor.id);

        if (antinuke === false) return;
        if (trusted === true) return;
        if (owner === true) return;
        if (executor.id === client.user.id) return;
        if (executor.id === webhook.guild.ownerId) return;

        const member = await webhook.guild.members.fetch(executor.id).catch(() => null);
        if (member) member.ban({ reason: "© Nityam Anti Webhook Create" }).catch(() => {});

        const logChannel = webhook.guild.channels.cache.get(data.logChannel);
        if (logChannel) {
          logChannel.send({
            embeds: [
              new EmbedBuilder()
                .setColor(client.color)
                .setAuthor({
                  name: client.user.username,
                  iconURL: client.user.displayAvatarURL(),
                })
                .addFields(
                  {
                    name: "Category",
                    value: `> Anti Webhook Create`,
                  },
                  {
                    name: "Log Type",
                    value: "> User Banned",
                  },
                  {
                    name: "User",
                    value: `> ${executor} ${executor.id}`,
                  },
                  {
                    name: "Reason",
                    value: "> Creating Webhooks",
                  }
                )
                .setFooter({ text: `© Nityam Antinuke Logs` })
                .setTimestamp(),
            ],
          });
        }
      }
    );
  });

  client.on("webhookUpdate", async (webhook) => {
    if(!webhook.guild.members.me.permissions.has(PermissionFlagsBits.ViewAuditLog)) return;
    const auditLog = await webhook.guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.WebhookDelete,
    });
    const logs = auditLog.entries.first();
    if(!logs) return;
    const { executor } = logs;

    await GuildSettings.findOne(
      { guildId: webhook.guild.id },
      async (err, data) => {
        if(!data) return;
        const antinuke = data.enabled.webhooks;
        const trusted = isTrusted(webhook.guild, executor.id, data.whitelist.webhooks);
        const owner = data.ownerLevel.includes(executor.id);

        if (antinuke === false) return;
        if (trusted === true) return;
        if (owner === true) return;
        if (executor.id === client.user.id) return;
        if (executor.id === webhook.guild.ownerId) return;

        const member = await webhook.guild.members.fetch(executor.id).catch(() => null);
        if (member) member.ban({ reason: "© Nityam Anti Webhook Delete" }).catch(() => {});

        const logChannel = webhook.guild.channels.cache.get(data.logChannel);
        if (logChannel) {
          logChannel.send({
            embeds: [
              new EmbedBuilder()
                .setColor(client.color)
                .setAuthor({
                  name: client.user.username,
                  iconURL: client.user.displayAvatarURL(),
                })
                .addFields(
                  {
                    name: "Category",
                    value: `> Anti Webhook Delete`,
                  },
                  {
                    name: "Log Type",
                    value: "> User Banned",
                  },
                  {
                    name: "User",
                    value: `> ${executor} ${executor.id}`,
                  },
                  {
                    name: "Reason",
                    value: "> © Nityam Anti Webhook Delete",
                  }
                )
                .setFooter({ text: `© Nityam Antinuke Logs` })
                .setTimestamp(),
            ],
          });
        }
      }
    );
  });

  //=================================== Anti Guild Update ===================================//
  client.on('guildUpdate',  async (o, n) => {

    const auditLog = await o.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.GuildUpdate,
    });
           
    const logs = auditLog.entries.first();
          
    if (!logs) return;
    const { executor } = logs;
      
         await GuildSettings.findOne(
      { guildId: n.id },
      async (err, data) => {      
        if (!data) return;
        const antinuke = data.guildId;
        const trusted = isTrusted(n, executor.id, data.whitelist.guildUpdate);
        const owner = data.ownerLevel.includes(executor.id);

        if (antinuke === false) return;
        if (trusted === true) return;
        if (owner === true) return;
        if (executor.id === client.user.id) return;
                 
          const oldIcon = o.iconURL();
          
          const oldName = o.name;
          
          const newIcon = n.iconURL();
          const newName = n.name;
          
          if (oldName !== newName) {
            await n.setName(oldName);
          }
          
          if (oldIcon !== newIcon) {
            await o.setIcon(oldIcon);
          }
          
          const member = await n.guild.members.fetch(executor.id).catch(() => null);
          if (member) member.ban({ reason: "© Nityam Anti Guild Update" }).catch(() => {});
          const logChannel = webhook.guild.channels.cache.get(data.logChannel);
          if (logChannel) {
            logChannel.send({
              embeds: [
                new EmbedBuilder()
                  .setColor(client.color)
                  .setAuthor({
                    name: client.user.username,
                    iconURL: client.user.displayAvatarURL(),
                  })
                  .addFields(
                    {
                      name: "Category",
                      value: `> Anti Guild Update`,
                    },
                    {
                      name: "Log Type",
                      value: "> User Banned",
                    },
                    {
                      name: "User",
                      value: `> ${executor} ${executor.id}`,
                    },
                    {
                      name: "Reason",
                      value: "> © Nityam Anti Guild Update",
                    }
                  )
                  .setFooter({ text: `© Nityam Antinuke Logs` })
                  .setTimestamp(),
              ],
            });
          }
          
        
      })
  });

  //=================================== Anti Everyone / Here ===================================//
  client.on('messageCreate', async (message) => {
    if (!message.guild) return;
    if (message.author.bot) return;
    if (!message.mentions.everyone) return;

    const data = await GuildSettings.findOne({ guildId: message.guild.id });
    if (!data) return;

    const antinuke = data.enabled.everyone;
    const trusted = isTrusted(message.guild, message.author.id, data.whitelist.everyone || []);
    const owner = data.ownerLevel.includes(message.author.id);

    if (!antinuke) return;
    if (trusted) return;
    if (owner) return;
    if (message.author.id === message.guild.ownerId) return;
    if (message.author.id === client.user.id) return;

    try { await message.delete(); } catch {}

    const member = message.guild.members.cache.get(message.author.id);
    if (member) {
      await member.ban({ reason: '© Nityam Anti Everyone/Here Mention' }).catch(() => {});
    }

    const logChannel = message.guild.channels.cache.get(data.logChannel);
    if (logChannel) {
      logChannel.send({
        embeds: [
          new EmbedBuilder()
            .setColor('Red')
            .setAuthor({ name: client.user.username, iconURL: client.user.displayAvatarURL() })
            .setTitle('🚨 Anti Everyone / Here Tetiklendi')
            .addFields(
              { name: 'Kategori', value: '> Anti Everyone/Here Mention' },
              { name: 'İşlem', value: '> Kullanıcı Banlandı + Mesaj Silindi' },
              { name: 'Kullanıcı', value: `> ${message.author} \`${message.author.id}\`` },
              { name: 'Kanal', value: `> ${message.channel}` },
              { name: 'Sebep', value: '> @everyone veya @here kullanımı' }
            )
            .setFooter({ text: '© Nityam Antinuke Logs' })
            .setTimestamp(),
        ],
      }).catch(() => {});
    }
  });
};
