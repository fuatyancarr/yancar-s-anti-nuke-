const { db: getDb } = require('./Firebase');

function deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
}

function setPath(obj, path, val) {
    const parts = path.split('.');
    let cur = obj;
    for (let i = 0; i < parts.length - 1; i++) {
        if (cur[parts[i]] == null || typeof cur[parts[i]] !== 'object') cur[parts[i]] = {};
        cur = cur[parts[i]];
    }
    cur[parts[parts.length - 1]] = val;
}

function getPath(obj, path) {
    return path.split('.').reduce((o, p) => (o == null ? undefined : o[p]), obj);
}

function applyUpdate(target, update) {
    if (!update) return;
    if (update.$set) {
        for (const [path, val] of Object.entries(update.$set)) setPath(target, path, val);
    }
    if (update.$inc) {
        for (const [path, val] of Object.entries(update.$inc)) {
            setPath(target, path, (getPath(target, path) || 0) + val);
        }
    }
    if (update.$push) {
        for (const [path, val] of Object.entries(update.$push)) {
            const arr = getPath(target, path) || [];
            arr.push(val);
            setPath(target, path, arr);
        }
    }
    if (update.$pull) {
        for (const [path, val] of Object.entries(update.$pull)) {
            const arr = getPath(target, path) || [];
            setPath(target, path, arr.filter(x => x !== val));
        }
    }
    if (update.$unset) {
        for (const path of Object.keys(update.$unset)) setPath(target, path, null);
    }
    for (const [k, v] of Object.entries(update)) {
        if (!k.startsWith('$')) target[k] = v;
    }
}

function toData(doc) {
    const out = {};
    for (const k of Object.keys(doc)) {
        if (k.startsWith('_')) continue;
        if (typeof doc[k] === 'function') continue;
        out[k] = doc[k];
    }
    return out;
}

function createModel(collection, keyFnOrField, defaults = {}) {
    const keyFn = typeof keyFnOrField === 'function'
        ? keyFnOrField
        : (data) => data && data[keyFnOrField];

    const col = () => getDb.call ? getDb.call({}) : null;
    const getCollection = () => require('./Firebase').db.collection(collection);

    class Doc {
        constructor(data = {}, isNew = true) {
            const merged = deepClone(defaults);
            Object.assign(merged, data);
            for (const [k, v] of Object.entries(merged)) this[k] = v;
            Object.defineProperty(this, '_isNew', { value: isNew, writable: true, enumerable: false });
        }

        async save() {
            const id = keyFn(this);
            if (id == null) throw new Error(`Document missing key for collection "${collection}"`);
            await getCollection().doc(String(id)).set(toData(this), { merge: false });
            this._isNew = false;
            return this;
        }

        async deleteOne() {
            const id = keyFn(this);
            if (id == null) return;
            await getCollection().doc(String(id)).delete();
        }
    }

    function buildQuery(query) {
        let q = getCollection();
        for (const [field, val] of Object.entries(query || {})) {
            if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
                if ('$lte' in val) q = q.where(field, '<=', val.$lte);
                else if ('$lt'  in val) q = q.where(field, '<',  val.$lt);
                else if ('$gte' in val) q = q.where(field, '>=', val.$gte);
                else if ('$gt'  in val) q = q.where(field, '>',  val.$gt);
                else if ('$ne'  in val) q = q.where(field, '!=', val.$ne);
                else if ('$in'  in val) q = q.where(field, 'in', val.$in);
                else q = q.where(field, '==', val);
            } else {
                q = q.where(field, '==', val);
            }
        }
        return q;
    }

    function Model(data) {
        return new Doc(data, true);
    }

    Model.findOne = async function(query, callback) {
        try {
            let result = null;
            const id = keyFn(query || {});

            if (id != null && typeof id !== 'object') {
                const snap = await getCollection().doc(String(id)).get();
                if (snap.exists) result = new Doc(snap.data(), false);
            } else {
                const snap = await buildQuery(query).limit(1).get();
                if (!snap.empty) result = new Doc(snap.docs[0].data(), false);
            }

            if (callback) await callback(null, result);
            return result;
        } catch (err) {
            if (callback) { await callback(err, null); return null; }
            throw err;
        }
    };

    Model.find = async function(query) {
        const q = (query && Object.keys(query).length) ? buildQuery(query) : getCollection();
        const snap = await q.get();
        return snap.docs.map(d => new Doc(d.data(), false));
    };

    Model.create = async function(data) {
        const doc = new Doc(data, true);
        return doc.save();
    };

    Model.insertMany = async function(docs, options = {}) {
        const batch = require('./Firebase').db.batch();
        const created = [];
        for (const data of docs) {
            const id = keyFn(data);
            const ref = id != null
                ? getCollection().doc(String(id))
                : getCollection().doc();
            batch.set(ref, toData(new Doc(data, true)));
            created.push(new Doc(data, false));
        }
        await batch.commit();
        return created;
    };

    Model.findOneAndUpdate = async function(query, update, options = {}) {
        const existing = await Model.findOne(query);
        let target;
        if (!existing) {
            if (!options.upsert) return null;
            target = new Doc({ ...query }, true);
        } else {
            target = existing;
        }
        applyUpdate(target, update);
        await target.save();
        return options.new === false ? existing : target;
    };

    Model.findOneAndDelete = async function(query) {
        const existing = await Model.findOne(query);
        if (!existing) return null;
        await existing.deleteOne();
        return existing;
    };

    Model.updateMany = async function(query, update) {
        const docs = await Model.find(query);
        const batch = require('./Firebase').db.batch();
        for (const d of docs) {
            applyUpdate(d, update);
            const id = keyFn(d);
            if (id != null) batch.set(getCollection().doc(String(id)), toData(d));
        }
        await batch.commit();
        return { matchedCount: docs.length, modifiedCount: docs.length };
    };

    Model.deleteMany = async function(query) {
        const docs = await Model.find(query);
        const batch = require('./Firebase').db.batch();
        for (const d of docs) {
            const id = keyFn(d);
            if (id != null) batch.delete(getCollection().doc(String(id)));
        }
        await batch.commit();
        return { deletedCount: docs.length };
    };

    Model.collectionName = collection;
    return Model;
}

module.exports = { createModel };
