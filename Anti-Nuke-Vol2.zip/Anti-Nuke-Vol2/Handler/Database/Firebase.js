const admin = require('firebase-admin');

let dbInstance = null;

function normalizePrivateKey(key) {
    if (typeof key !== 'string') return key;
    let k = key.trim();
    if ((k.startsWith('"') && k.endsWith('"')) || (k.startsWith("'") && k.endsWith("'"))) {
        k = k.slice(1, -1);
    }
    if (k.includes('\\n')) {
        k = k.replace(/\\n/g, '\n');
    }
    if (k.includes('\\r')) {
        k = k.replace(/\\r/g, '');
    }
    k = k.replace(/\r/g, '');
    return k;
}

function init() {
    if (dbInstance) return dbInstance;

    let raw = process.env.FIREBASE_SERVICE_ACCOUNT_KEY;
    if (!raw) {
        throw new Error('FIREBASE_SERVICE_ACCOUNT_KEY ortam değişkeni tanımlı değil!');
    }

    raw = raw.trim();
    if ((raw.startsWith("'") && raw.endsWith("'"))) {
        raw = raw.slice(1, -1);
    }

    let credentials;
    try {
        credentials = JSON.parse(raw);
    } catch (e) {
        try {
            credentials = JSON.parse(raw.replace(/\n/g, '\\n').replace(/\r/g, ''));
        } catch (e2) {
            throw new Error('FIREBASE_SERVICE_ACCOUNT_KEY geçerli bir JSON değil: ' + e.message);
        }
    }

    // Bazı tarayıcılar (Chrome auto-translate) JSON anahtarlarını çevirebilir; düzelt:
    const fieldAliases = {
        'tür': 'type',
        'tip': 'type',
        'özel_anahtar': 'private_key',
        'özel_anahtar_kimliği': 'private_key_id',
        'müşteri_e_postası': 'client_email',
        'müşteri_kimliği': 'client_id',
    };
    for (const [alias, real] of Object.entries(fieldAliases)) {
        if (credentials[alias] && !credentials[real]) {
            credentials[real] = credentials[alias];
            delete credentials[alias];
        }
    }

    if (credentials.private_key) {
        credentials.private_key = normalizePrivateKey(credentials.private_key);
        // PEM başlık/sonunun çevrilmiş halini düzelt
        credentials.private_key = credentials.private_key
            .replace(/-----ÖZEL ANAHTAR BAŞLANGICI-----/g, '-----BEGIN PRIVATE KEY-----')
            .replace(/-----ÖZEL ANAHTAR SONU-----/g, '-----END PRIVATE KEY-----')
            .replace(/-----BAŞLANGIÇ ÖZEL ANAHTARI-----/g, '-----BEGIN PRIVATE KEY-----')
            .replace(/-----SON ÖZEL ANAHTARI-----/g, '-----END PRIVATE KEY-----');
    }

    if (!credentials.private_key
        || !credentials.private_key.includes('-----BEGIN PRIVATE KEY-----')
        || !credentials.private_key.includes('-----END PRIVATE KEY-----')) {
        throw new Error('private_key geçerli PEM formatında değil. Service account JSON dosyasını tarayıcı çevirisi yapmadan, bir metin editöründen kopyalayıp tekrar dene.');
    }

    if (!admin.apps.length) {
        admin.initializeApp({
            credential: admin.credential.cert(credentials),
            projectId: credentials.project_id,
        });
    }

    dbInstance = admin.firestore();
    dbInstance.settings({ ignoreUndefinedProperties: true });

    return dbInstance;
}

module.exports = {
    init,
    get db() { return init(); },
    admin,
};
