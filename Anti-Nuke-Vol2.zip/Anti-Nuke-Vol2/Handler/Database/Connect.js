const { init } = require('./Firebase');

module.exports = async () => {
    try {
        init();
        console.log('[INFO] Firebase Firestore bağlantısı kuruldu.');
    } catch (error) {
        console.log('[ERROR] Firebase başlatma hatası:', error.message);
    }
};
