const cron = require('node-cron');
const Premium = require("../../Models/Premium");

module.exports = async (client) => {
  cron.schedule('*/60 * * * * *', async () => {
    try {
      const expired = await Premium.find({
        isPremium: true,
        'premium.expiresAt': { $lte: Date.now() }
      }).select('Id').lean();

      if (!expired.length) return;

      const ids = expired.map(u => u.Id);

      await Premium.updateMany(
        { Id: { $in: ids } },
        {
          $set: {
            isPremium: false,
            'premium.redeemedBy': [],
            'premium.redeemedAt': null,
            'premium.expiresAt': null,
            'premium.plan': null,
          }
        }
      );

      for (const id of ids) client.premiums.delete(id);
    } catch (e) {}
  });
};
