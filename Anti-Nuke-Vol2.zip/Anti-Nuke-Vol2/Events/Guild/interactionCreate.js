const { PermissionsBitField, EmbedBuilder } = require("discord.js");
const chalk = require("chalk");
const Verify = require("../../Models/Verify");

module.exports = async (client, interaction) => {
    //=================================== Buton Etkileşimi =====================================\\
    if (interaction.isButton()) {
        if (interaction.customId === "verify-button") {
            const verifyData = await Verify.findOne({ guildId: interaction.guild.id });
            if (!verifyData || !verifyData.roleId) {
                return interaction.reply({ content: "Verify sistemi bu sunucuda ayarlanmamış.", ephemeral: true });
            }

            const rol = interaction.guild.roles.cache.get(verifyData.roleId);
            if (!rol) {
                return interaction.reply({ content: "Verify rolü bulunamadı. Lütfen yöneticiye bildir.", ephemeral: true });
            }

            const uye = interaction.member;
            if (uye.roles.cache.has(rol.id)) {
                return interaction.reply({ content: "Zaten doğrulanmışsın!", ephemeral: true });
            }

            await uye.roles.add(rol).catch(() => null);
            await interaction.reply({ content: `✅ Başarıyla doğrulandın! \`${rol.name}\` rolü verildi.`, ephemeral: true });

            if (verifyData.logChannelId) {
                const logKanal = interaction.guild.channels.cache.get(verifyData.logChannelId);
                if (logKanal) {
                    logKanal.send({
                        embeds: [
                            new EmbedBuilder()
                                .setColor("Green")
                                .setTitle("✅ Kullanıcı Doğrulandı")
                                .addFields(
                                    { name: "Kullanıcı", value: `${uye} \`${uye.user.tag}\``, inline: true },
                                    { name: "ID", value: `\`${uye.id}\``, inline: true },
                                    { name: "Verilen Rol", value: `${rol}`, inline: true }
                                )
                                .setThumbnail(uye.user.displayAvatarURL({ dynamic: true }))
                                .setTimestamp()
                        ]
                    }).catch(() => {});
                }
            }
        }
        return;
    }

    //=================================== Komut Etkileşimi =====================================\\
    if (
        interaction.isCommand ||
        interaction.isContextMenuCommand ||
        interaction.isChatInputCommand
    ) {
        if (!interaction.guild || interaction.user.bot) return;

        const user = client.premiums.get(interaction.user.id);

        let subCommandName = "";
        try {
            subCommandName = interaction.options.getSubcommand();
        } catch {}
        let subCommandGroupName = "";
        try {
            subCommandGroupName = interaction.options.getSubcommandGroup();
        } catch {}

        const command = client.slash.find((command) => {
            switch (command.name.length) {
                case 1:
                    return command.name[0] == interaction.commandName;
                case 2:
                    return (
                        command.name[0] == interaction.commandName &&
                        command.name[1] == subCommandName
                    );
                case 3:
                    return (
                        command.name[0] == interaction.commandName &&
                        command.name[1] == subCommandGroupName &&
                        command.name[2] == subCommandName
                    );
            }
        });
        if (!command) return;

        console.log(
            chalk.bgRed(
                `[COMMAND] ${interaction.user.tag} Used ${command.name.at(-1)} in ${interaction.guild.name} (${interaction.guild.id})`
            )
        );

        if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.SendMessages))
            return interaction.user.dmChannel.send(`Mesaj göndermek için yetkim yok.`);
        if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.ViewChannel))
            return;
        if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.EmbedLinks))
            return interaction.reply({ content: `Embed bağlantısı için yetkim yok.`, ephemeral: true });

        const { channel } = interaction.member.voice;

        if (command.settings.inVoice) {
            if (!channel)
                return interaction.reply({ content: `Bu komut için bir ses kanalında olman gerekiyor.`, ephemeral: true });
            if (!interaction.guild.members.cache.get(client.user.id).permissionsIn(channel).has(command.permissions.channel || []))
                return interaction.reply({ content: `Ses kanalında gerekli yetkim yok.`, ephemeral: true });
        }

        if (command.settings.isPremium && (!user || !user.isPremium)) {
            return interaction.reply({ content: `Bu komut premium kullanıcılara özeldir.`, ephemeral: true });
        }

        if (command.settings.isOwner && interaction.user.id !== client.owner) {
            return interaction.reply({ content: `Bu komut yalnızca bot sahibine özeldir.`, ephemeral: true });
        }

        if (command.settings.isNSFW && !interaction.channel.nsfw) {
            return interaction.reply({ content: `Bu komut yalnızca NSFW kanallarda kullanılabilir.`, ephemeral: true });
        }

        if (!interaction.guild.members.me.permissions.has(command.permissions.bot || [])) {
            return interaction.reply({ content: `Bu komut için gerekli yetkim yok: \`${command.permissions.bot.join(", ")}\``, ephemeral: true });
        }

        if (!interaction.member.permissions.has(command.permissions.user || [])) {
            return interaction.reply({ content: `Bu komutu kullanmak için şu yetkiye ihtiyacın var: \`${command.permissions.user.join(", ")}\``, ephemeral: true });
        }

        if (command) {
            try {
                command.run(interaction, client);
            } catch (error) {
                await interaction.reply({ content: `Komut çalıştırılırken bir hata oluştu.`, ephemeral: true });
            }
        }
    }
};
