const { EmbedBuilder } = require("discord.js");
const OtoRol = require("../../Models/OtoRol");
const Hosgeldin = require("../../Models/Hosgeldin");

module.exports = async (client, member) => {
    if (member.user.bot) return;

    // --- Otorol ---
    try {
        const otoRol = await OtoRol.findOne({ guildId: member.guild.id });
        if (otoRol && otoRol.aktif && otoRol.rolId) {
            const rol = member.guild.roles.cache.get(otoRol.rolId);
            if (rol) {
                await member.roles.add(rol).catch(() => {});
            }
        }
    } catch {}

    // --- Hoşgeldin ---
    try {
        const hosgeldin = await Hosgeldin.findOne({ guildId: member.guild.id });
        if (hosgeldin && hosgeldin.aktif && hosgeldin.kanalId) {
            const kanal = member.guild.channels.cache.get(hosgeldin.kanalId);
            if (kanal) {
                const mesaj = hosgeldin.mesaj
                    .replace("{kullanici}", member.user.toString())
                    .replace("{sunucu}", member.guild.name)
                    .replace("{uye_sayisi}", member.guild.memberCount);

                await kanal.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(hosgeldin.embedRenk || "#5865F2")
                            .setTitle("👋 Hoşgeldiniz!")
                            .setDescription(mesaj)
                            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                            .setFooter({ text: `${member.guild.name} • ${member.guild.memberCount}. üye`, iconURL: member.guild.iconURL({ dynamic: true }) })
                            .setTimestamp()
                    ]
                }).catch(() => {});
            }
        }
    } catch {}
};
