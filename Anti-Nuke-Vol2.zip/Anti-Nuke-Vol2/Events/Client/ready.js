const { green, white } = require('chalk');
const Premium = require('../../Models/Premium');

module.exports = async (client) => {
    console.log(white('[') + green('INFO') + white('] ') + green(`${client.user.tag} (${client.user.id})`) + white(` is Ready!`));

    try {
        const users = await Premium.find();
        for (let user of users) {
            client.premiums.set(user.Id, user);
        }
    } catch (e) {}

    const updatePresence = () => {
        const guilds = client.guilds.cache.size;
        const members = client.guilds.cache.reduce((a, b) => a + (b.memberCount || 0), 0);

        const activities = [
            `Made By fuatyancar`,
            `${members} kullanıcı koruyor`,
            `${guilds} sunucuda aktif`,
        ];

        const i = Math.floor(Math.random() * activities.length);
        client.user.setPresence({
            activities: [{ name: activities[i], type: 0 }],
            status: 'online',
        });
    };

    updatePresence();
    setInterval(updatePresence, 15000);
};
